const { test, expect } = require('@playwright/test');

test('Screenshots and Videos', async ({ browser }) => {
  // Create a new context and enable video recording
  const context = await browser.newContext({
    recordVideo: {
      dir: 'tests/LearnP/Section7/',  // Directory to store video files
      size: { width: 1280, height: 720 },  // Optional: set video size
    }
  });

  // Create a new page
  const page = await context.newPage();

  // Navigate to a webpage
  await page.goto('https://parabank.parasoft.com/parabank/overview.htm');``

  // Capture a full-page screenshot
  await page.screenshot({ path: 'tests/LearnP/Section7/fullpage-screenshot.jpeg', fullPage: true });

  // Interact with the page (Login)
  await page.locator('//input[@name="username"]').first().fill('john');
  await page.locator('//input[@name="password"]').first().fill('demo');
  await page.locator("//*[@value='Log In']").first().click();

  // Wait for the dashboard to load and check if login is successful
  await page.waitForTimeout(2000);
  const dashboard = await page.locator('.smallText').first().textContent();
  await expect(dashboard).toContain('Welcome');

  // Wait for a few seconds to allow video recording to capture actions
  await page.waitForTimeout(5000); // Wait for 5 seconds

  // Close the context (this also saves the video)
  await context.close();
});
